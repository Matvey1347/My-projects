# overdoze sans font

[Download](overdozesans.otf)

![preview](preview.png)

Created via FontLab 7
